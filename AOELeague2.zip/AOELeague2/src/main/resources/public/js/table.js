/**
 * Created by ThanhND20 on 12/23/2016.
 */
$(function () {
	$('.lbl-player-top').each(function () {
		var topValue = $(this).html();
		alert(topValue);
	}
});

package com.sonic.AOELeague.service;

import org.junit.Test;

import com.sonic.aoeleague.service.GenerateMatchService;


public class GenerateMatchServiceTest {
}
